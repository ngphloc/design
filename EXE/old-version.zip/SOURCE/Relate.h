// Relate.h: interface for the CRelate class.
//
//////////////////////////////////////////////////////////////////////
	  /************************************************
	   * Sinh vien : Nguyen Phuoc Loc    MSSV: 9700454*
	   ************************************************/

#if !defined(AFX_RELATE_H__E9324291_1A09_11D4_A3E3_D1558B86324A__INCLUDED_)
#define AFX_RELATE_H__E9324291_1A09_11D4_A3E3_D1558B86324A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <Afxtempl.h>

//Lop CFunc mo ta phu thuoc ham X->Y 
//hay phu thuoc da tri X->>Y

class CFunc
{
protected:
	CStringArray	m_aszX;
	CStringArray	m_aszY;
	BOOL			m_bFlag;//TRUE : phu thuoc ham
							//FALSE : phu thuoc da tri

public:
	CFunc();
	CFunc(CFunc& Func);
	virtual ~CFunc();

	CStringArray&	GetX();
	CStringArray&	GetY();
	BOOL			GetFlag();

	void SetX(CStringArray&  aszX);
	void SetY(CStringArray&  aszY);
	void SetFlag(BOOL Flag);

	void	SetFunc(CFunc& Func);
	CFunc&	operator =  (CFunc& Func);
	BOOL	operator == (CFunc& Func);
	BOOL	operator != (CFunc& Func);

	void Empty();
	BOOL IsEmpty();
}; 

//Moi quan he duoc xem nhu mot doi tuong gom tap thuoc tinh
//va tap phu thuoc ham, phu thuoc da tri
class CRelate  
{
protected:
	CString				  m_szR;//quan he R
	CArray<CFunc, CFunc&> m_aD;//tap phu thuoc ham hay phu thuoc da tri
	CStringArray          m_aszK; //tap cac khoa
public:
	CRelate();
	CRelate(CRelate& Relate);
	CRelate(CArray<CRelate,CRelate&>& aInput);
	virtual ~CRelate();

	void	  SetRelate(CRelate& Relate);
	void	  SetRelate(CArray<CRelate,CRelate&>& aInput);
	CRelate&  operator =  (CRelate& Relate);
	CRelate&  operator =  (CArray<CRelate,CRelate&>& aInput);
	BOOL      operator == (CRelate& Relate);
	BOOL      operator != (CRelate& Relate);
	CRelate&  operator += (CRelate& Relate);
	CRelate  operator +  (CRelate& Relate);

	CString&				GetR();
	void	GetD(CArray<CFunc, CFunc&>& aD);
	void	GetK(CStringArray& aszK);

	void SetR(CString& R);
	void SetD(CArray<CFunc, CFunc&>& aD);
	void SetK(CStringArray& aszK);
	
	void Empty();
	BOOL IsEmpty();
	void Output(CString& szS);

	void EssenceD();
	void EssenceR();
	void EssenceRD();

	BOOL BagOfX(CString X, CString& XF);//Bao dong
	BOOL BagOfX(CStringArray& aszX, CStringArray& aszY);//Bao dong
	BOOL FindPhuTT(CArray<CFunc, CFunc&>&  aPTT);//Tim phu toi thieu
	BOOL FindKey();//Tim khoa
	BOOL DependOfX(CString X, CStringArray& G);//ham tim tap phu thuoc cua X

};

//Ham phan ra
//Vao  Relate:Quan he R
//Ra   aDisRelate:mang chua cac quan he 
void DisRelate(CRelate Relate, CArray<CRelate, CRelate&>& aDisRelate);
			////////////////////////////
//Ham phan ra cai tien : chon ham phan ra la ham vi pham tieu chuan BCK hay
//co ve phai khong xuat hien o ve phai cua cac phu thuoc ham khac
void DisRelateEnhanced(CRelate Relate, CArray<CRelate, CRelate&>& aDisRelate);
			////////////////////////////
//Ham tong hop cai tien
//Vao  Relate:Quan he R
//Ra   aCollectRelate:mang chua cac quan he 
void Collect(CRelate Relate, CArray<CRelate, CRelate&>& aCollectRelate);
			////////////////////////////
//Thuat toan bieu dien mot phan ra duoi dang do thi
//Vao : phan ra aInput;
//Ra  : tap cac nut aOutput
//      Ma tran ke aGraph

BOOL PerformToGraph(CArray<CRelate,CRelate&>& aInput,
					CArray<CRelate,CRelate&>& aOutput,
					CArray<CUIntArray,CUIntArray&>& aGraph);
//Vao : tap cac quan he aQ
//      quan he cha Q 
BOOL Tableau(CArray<CRelate,CRelate&>& aQ);
#endif // !defined(AFX_RELATE_H__E9324291_1A09_11D4_A3E3_D1558B86324A__INCLUDED_)
