// Relate.cpp: implementation of the CRelate class.
//
//////////////////////////////////////////////////////////////////////
	  /************************************************
	   * Sinh vien : Nguyen Phuoc Loc    MSSV: 9700454*
	   ************************************************/

#include "stdafx.h"
#include "Design.h"
#include "Relate.h"
#include "Tool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CFunc::CFunc()
{
	Empty();
}
CFunc::CFunc(CFunc& Func)
{
	SetFunc(Func);
}
CFunc:: ~CFunc()
{
	Empty();
}

void CFunc::SetFunc(CFunc& Func)
{
	SetX(Func.GetX());
	SetY(Func.GetY());
	SetFlag(Func.GetFlag());
}
CFunc& CFunc::operator = (CFunc& Func)
{
	SetFunc(Func);
	return *this;
}
BOOL CFunc::operator == (CFunc& Func)
{
	CString X1,Y1,X2,Y2;
	BOOL Flag1,Flag2,ret;
	X1=Union(m_aszX);Y1=Union(m_aszY);
	X2=Union(Func.GetX());Y2=Union(Func.GetY());
	Flag1=m_bFlag;
	Flag2=Func.GetFlag();
	
	ret=(IsEqual(X1,X2))&&(IsEqual(Y1,Y2))&&((Flag1==TRUE&&Flag2==TRUE)||
							 (Flag1==FALSE&&Flag2==FALSE));
	return ret;
}
BOOL CFunc::operator != (CFunc& Func)
{
	CString X1,Y1,X2,Y2;
	BOOL Flag1,Flag2,ret;
	X1=Union(m_aszX);Y1=Union(m_aszY);
	X2=Union(Func.GetX());Y2=Union(Func.GetY());
	Flag1=m_bFlag;
	Flag2=Func.GetFlag();
	
	ret=(!IsEqual(X1,X2))||(!IsEqual(Y1,Y2))||(Flag1==TRUE&&Flag2==FALSE)||
							(Flag1==FALSE&&Flag2==TRUE);
	return ret;

}

CStringArray& CFunc::GetX()
{
	return m_aszX;
}
CStringArray& CFunc::GetY()
{
	return m_aszY;
}
BOOL CFunc::GetFlag()
{
	return m_bFlag;
}
	
void CFunc::SetX(CStringArray&  aszX)
{
	int i;
	CString tempS;
	m_aszX.RemoveAll();
	for(i=0;i<aszX.GetSize();i++)
	{
		tempS=Essence(aszX[i]);
		m_aszX.Add(tempS);
	}
}
void CFunc::SetY(CStringArray&  aszY)
{
	int i;
	CString tempS;
	m_aszY.RemoveAll();
	for(i=0;i<aszY.GetSize();i++)
	{
		tempS=Essence(aszY[i]);
		m_aszY.Add(tempS);
	}
}
void CFunc::SetFlag(BOOL Flag)
{
	m_bFlag = Flag;
}
void CFunc::Empty()
{
	m_aszX.RemoveAll();
	m_aszY.RemoveAll();

}
BOOL CFunc::IsEmpty()
{
	if(m_aszX.GetSize() && m_aszY.GetSize())
		return FALSE;

	return TRUE;
}

/************************************************************/
CRelate::CRelate()
{
	Empty();	
}
CRelate::CRelate(CRelate& Relate)
{
	SetRelate(Relate);
}
CRelate::CRelate(CArray<CRelate,CRelate&>& aInput)
{
	SetRelate(aInput);
}
CRelate::~CRelate()
{
	Empty();
}

void CRelate::SetRelate(CRelate& Relate)
{
	CArray<CFunc, CFunc&>  aD;
	SetR(Relate.GetR());
	Relate.GetD(aD);
	SetD(aD);
}
void CRelate::SetRelate(CArray<CRelate,CRelate&>& aInput)
{
	CString tempS;
	CStringArray aK;
	int i,j;

	for(i=0;i<aInput.GetSize();i++)
		tempS +=aInput[i].GetR();
	SetR(tempS);

	m_aD.RemoveAll();
	for(i=0;i<aInput.GetSize();i++)
	{
		CArray<CFunc,CFunc&> aTempD;
		aInput[i].GetD(aTempD);
		for(j=0;j<aTempD.GetSize();j++)
			m_aD.Add(aTempD[j]);
	}
	
}
CRelate& CRelate::operator = (CRelate& Relate)
{
	SetRelate(Relate);
	return *this;
}
CRelate& CRelate::operator = (CArray<CRelate,CRelate&>& aInput)
{
	SetRelate(aInput);
	return *this;
}
BOOL CRelate::operator == (CRelate& Relate)
{
	//To do code
	return TRUE;
}
BOOL CRelate::operator != (CRelate& Relate)
{
	//To do code
	return TRUE;
}
CRelate& CRelate::operator += (CRelate& Relate)
{
	m_szR+=Relate.GetR();
	CArray<CFunc,CFunc&> aD;
	Relate.GetD(aD);
	for(int i=0;i<aD.GetSize();i++)
		m_aD.Add(aD[i]);
	return *this;
}
CRelate CRelate::operator +  (CRelate& Relate)
{
	CRelate tempRelate;
	CString szR;
	CArray<CFunc,CFunc&> aD;

	szR=m_szR+Relate.GetR();
	tempRelate.SetR(szR);

	Relate.GetD(aD);
	for(int i=0;i<m_aD.GetSize();i++)
		aD.Add(m_aD[i]);
	tempRelate.SetD(aD);

	return tempRelate;
}

CString& CRelate::GetR()
{
	return m_szR;
}

void CRelate::GetD(CArray<CFunc, CFunc&>& aD)
{
	aD.RemoveAll();
	for(int i=0;i<m_aD.GetSize();i++)
		aD.Add(m_aD[i]);
}

void CRelate::GetK(CStringArray& aszK)
{
	aszK.RemoveAll();
	for(int i=0;i<m_aszK.GetSize();i++)
		aszK.Add(m_aszK[i]);
}
	
void CRelate::SetR(CString&	R)
{
	m_szR=R;
	m_aszK.RemoveAll();
}
void CRelate::SetD(CArray<CFunc, CFunc&>&  aD)
{
	m_aD.RemoveAll();
	for(int i=0;i<aD.GetSize();i++)
		m_aD.Add(aD[i]);
	m_aszK.RemoveAll();
}
void CRelate::SetK(CStringArray& aszK)
{
	m_aszK.RemoveAll();
	for(int i=0;i<aszK.GetSize();i++)
		m_aszK.Add(aszK[i]);
}
void CRelate::Empty()
{
	m_szR.Empty();
	m_aD.RemoveAll();
	m_aszK.RemoveAll();
}
BOOL CRelate::IsEmpty()
{
	return m_szR.IsEmpty();
}
void CRelate::Output(CString& szS)
{
	CString szR;
	CString tempS;
	tempS = "R{ ";
	szR = tempS + m_szR + " }";

	CString szD;
	tempS = "D{ ";
	for(int i=0;i<m_aD.GetSize();i++)
	{
		CString X,Y,S;
		S = "( ";
		StringArrayToString(m_aD[i].GetX(),X);
		StringArrayToString(m_aD[i].GetY(),Y);
		if(m_aD[i].GetFlag() == TRUE)
			X = S + X + "->" + Y + " )";
		else
			X = S + X + "->>" + Y + " )";

		szD +=X ;
		if(i<m_aD.GetSize()-1)
			szD +=" , ";

	}
	szD = tempS + szD + " }";

	tempS = "< ";
	szS = tempS + szR + "  ;  " + szD + " >";
}

/*****Thuat toan tim bao dong cua mot tap X nho tap phu thuoc ham F*****/

//Vao Relate: quan he R 
//	  X:1 hay nhieu thuoc tinh
//Ra  FX: Bao dong cua tap X dua vao tap phu thuoc ham Relate.aD	

BOOL CRelate::BagOfX(CString X, CString& XF)
{
	if(m_szR.IsEmpty() || X.IsEmpty() || !IsIn(X,m_szR))
		return FALSE;
	
	CArray<CFunc, CFunc&>  aD;	
	CStringArray aX;
	int i,j;

	XF = X;
	for(i=0;i<m_aD.GetSize();i++)
		if(m_aD[i].GetFlag())
			aD.Add(m_aD[i]);
	if(aD.GetSize() == 0)
		return TRUE;

	for(i=0;i<3;i++)
		aX.Add(XF);

	while(aD.GetSize())
	{
		i=0;
		while(i<aD.GetSize())	
		{
			CString tempS;
			tempS = Union(aD[i].GetX());
			if(IsIn(tempS,XF))
			{
				tempS.IsEmpty();
				tempS = Union(aD[i].GetY());
				XF=Union(XF,tempS);
				aD.RemoveAt(i);
			}
			else	
				i++;
		}
		aX.RemoveAt(0);
		aX.Add(XF);

		if(IsEqual(XF,m_szR))
			break;

		for(j=0;j<aX.GetSize()-1;j++)
			if(!IsEqual(aX[j],aX[j+1]))		
				break;

		if(j==aX.GetSize()-1)//Neu Xn = Xn+1 = Xn+2
			break;
	}
	return TRUE;
}
BOOL CRelate::BagOfX(CStringArray& aszX, CStringArray& aszY)
{
	aszY.RemoveAll();
	int countFalse=0;
	for(int i=0;i<aszX.GetSize();i++)
	{
		CString tempS;
		BOOL ret=BagOfX(aszX[i],tempS);
		aszY.Add(tempS);
		if(!ret)
			countFalse++;
	}
	if(countFalse==aszX.GetSize())
		return FALSE;
	return TRUE;
}
/********************Thuat toan phu toi thieu****************/

//Ra aPTT : tap phu toi thieu
BOOL CRelate::FindPhuTT(CArray<CFunc, CFunc&>&  aPTT)
{
	if(m_szR.IsEmpty())
		return FALSE;

	int i,j;
	aPTT.RemoveAll();

	for(i=0;i<m_aD.GetSize();i++)
		if(m_aD[i].GetFlag())//Neu la phu thuoc ham
			aPTT.Add(m_aD[i]);
	if(aPTT.GetSize()==0)
		return FALSE;

//tao nhung phu thuoc ham day du	
	for(i=0;i<aPTT.GetSize();i++)
	{
		CStringArray aszC;
		CString S = Union(aPTT[i].GetX());
		Combine(S,"",0,aszC);
		Sort(aszC);
		for(j=0;j<aszC.GetSize();j++)
		{
			CString tempS;
			CRelate Relate;
			Relate.SetR(m_szR);
			Relate.SetD(aPTT);
			Relate.BagOfX(aszC[j],tempS);
			if(IsIn(aPTT[i].GetY(),tempS))
				break;
		}
		
		if(j<aszC.GetSize())
		{
			CFunc f(aPTT[i]);
			CStringArray aszX ;
			aszX.Add(aszC[j]);
			f.SetX(aszX);

			aPTT.SetAt(i,f);
		}

	}
	
//loai bo nhung phu thuoc ham thua	
	i=0;
	while(i<aPTT.GetSize())
	{
		CRelate Relate;
		CArray<CFunc, CFunc&>  aD;

		for(j=0;j<aPTT.GetSize();j++)
			aD.Add(aPTT[j]);
		aD.RemoveAt(i);
		
		Relate.SetR(m_szR);
		Relate.SetD(aD);
		CString tempS,XF;
		tempS = Union(aPTT[i].GetX());
		Relate.BagOfX(tempS,XF);
		tempS = Sub(aPTT[i].GetY(),XF);
		if(tempS.IsEmpty())
			aPTT.RemoveAt(i);
		else
		{
			CFunc f=aPTT[i];
			CStringArray aszTemp;
			aszTemp.Add(tempS);
			f.SetY(aszTemp);
			aPTT.SetAt(i,f);
			i++;
		}
			
	}
//loai bo nhung thuoc tinh thua o ve phai cua moi phu thuoc ham
	i=0;
	while(i<aPTT.GetSize())
	{
		CRelate Relate;
		CArray<CFunc, CFunc&>  aD;

		for(j=0;j<aPTT.GetSize();j++)
			aD.Add(aPTT[j]);
		aD.RemoveAt(i);
		Relate.SetR(m_szR);
		Relate.SetD(aD);

		CString tempS = Union(aPTT[i].GetY());

		j=0;
		while(j<tempS.GetLength())
		{
			CString S,X,XF,s1,s2;
			S+= tempS[j];
			s1 = tempS.Left(j);
			s2 = tempS.Mid(j,tempS.GetLength()-j);
			s2.TrimLeft(S);
			X = s1 + s2;

			Relate.BagOfX(X,XF);
			if(IsIn(S,XF))
				tempS = X;
			else
				j++;
		}
		
		if(tempS.IsEmpty())
			aPTT.RemoveAt(i);
		else
		{
			CFunc f=aPTT[i];
			CStringArray aszTemp;
			aszTemp.Add(tempS);
			f.SetY(aszTemp);
			aPTT.SetAt(i,f);
			i++;
		}

	}
//Nhap nhung phu thuoc ham co cung ve trai
	i=0;
	while(i<aPTT.GetSize()-1)
	{
		for(j=i+1;j<aPTT.GetSize();j++)
			if(IsEqual( Union(aPTT[i].GetX()),Union(aPTT[j].GetX())))
				break;
		if(j<aPTT.GetSize())
		{
			CFunc f=aPTT[i];
			CString tempS = Union( Union(aPTT[i].GetY()),Union(aPTT[j].GetY()));
			CStringArray aszTemp;
			aszTemp.Add(tempS);
			f.SetY(aszTemp);
			aPTT.SetAt(i,f);
			aPTT.RemoveAt(j);
		}
		else
			i++;
	}
	return TRUE;
}

/********************Thuat toan tim khoa*********************/

//Bien nay duoc dinh nghia trong Tool.cpp

BOOL CRelate::FindKey()
{
	if(m_szR.IsEmpty())
		return FALSE;

	if(m_aD.GetSize()==0)
	{
		m_aszK.Add(m_szR);
		return TRUE;
	}

	m_aszK.RemoveAll();	
	CString srcX, destY;//tap nguon, tap dich
	CString S,tempS;//Tap trung gian
	CStringArray aszTempX,aszTempY;
	int i;
	for(i=0;i<m_aD.GetSize();i++)
		if(m_aD[i].GetFlag())//Neu la phu thuoc ham
		{
			aszTempX.Append(m_aD[i].GetX());
			aszTempY.Append(m_aD[i].GetY());
		}
	tempS=srcX = Union(aszTempX);
	destY = Union(aszTempY);
	srcX = Sub(srcX,destY);//tao tap nguon
	destY = Sub(destY,tempS);//tao tap dich
	S=Sub(Sub(m_szR,srcX), destY);//Tao tap trung gian

	srcX=Common(srcX,m_szR);
	destY=Common(destY,m_szR);
	S=Common(S,m_szR);

	CString XF;
	BagOfX(srcX,XF);

	if(IsIn(m_szR,XF))//Neu tap srcX la khoa
	{
		m_aszK.Add(srcX);
		return TRUE;
	}

	CStringArray aszC;
	Combine(S,"",0,aszC);//tao cac to hop tu tap trung gian
	Sort(aszC);
	CString szK;
	while(aszC.GetSize())
	{
		tempS = aszC[0];
		szK = srcX + tempS;
		aszC.RemoveAt(0);

		XF.Empty();
		BagOfX(szK,XF);
		if(IsIn(m_szR,XF))//Neu tap szK la khoa
		{
			m_aszK.Add(szK);
			i=0;
			while(i<aszC.GetSize())
			{
				if(IsIn(tempS,aszC[i]))
					aszC.RemoveAt(i);
				else
					i++;
			}
		}
	}
	if(m_aszK.GetSize())
		return TRUE;
	AfxMessageBox("No Key",MB_OK,0);
	return FALSE;
}

/***********Thuat toan tim tap phu thuoc da tri cua X dua tren D*************/

//ham tim tap phu thuoc da tri cua X du tren tap phu thuoc ham
//Vao : X : tap thuoc tinh
//Ra  : G :tap Thuoc tinh cua X dua tren tap phu thuoc da tri

BOOL CRelate::DependOfX(CString szX, CStringArray& aszG)
{
	if(m_szR.IsEmpty() || szX.IsEmpty() || !IsIn(szX,m_szR))
		return FALSE;

	aszG.RemoveAll();
	int i;
	CString tempS;

	for(i=0;i<szX.GetLength();i++)
	{	
		tempS=szX[i];
		aszG.Add(tempS);
	}
	if(m_aD.GetSize()==0)
		return TRUE;

//Buoc 1
	CArray<CFunc, CFunc&>  aD;
	for(i=0;i<m_aD.GetSize();i++)
		aD.Add(m_aD[i]);

	for(i=0;i<aD.GetSize();i++)
	{
		if(IsIn(aD[i].GetX(),szX))
		{
			aszG.Append(aD[i].GetY());
			tempS = Union(aD[i].GetX()) + Union(aD[i].GetY());
			aszG.Add(Sub(m_szR,tempS));
		}
	}
//Buoc 2
	CStringArray tempG;
	Minimum(aszG,tempG);
	aszG.RemoveAll();
	aszG.Append(tempG);
	tempG.RemoveAll();
//Buoc 3
	//tao cac to hop co the cua aszG
	//aszC = new CStringArray; 
	CStringArray aszC; 
	Combine(aszG,"",0,aszC);
	Sort(aszC);
	int j,k;
	for(i=0;i<aD.GetSize();i++)
	{
		
		for(j=0;j<aszC.GetSize();j++)
		{
			if(IsIn(aD[i].GetX(),aszC.GetAt(j)))
			{
				tempS = Sub(aD[i].GetY(),aszC.GetAt(j));//Z-Y
				for(k=0;k<aszC.GetSize();k++)
					if(IsEqual(tempS,aszC.GetAt(k)))
						break;
				if(k==aszC.GetSize())//Neu khong ton tai
				{
					aszG.Add(tempS);
					Minimum(aszG,tempG);
					aszG.RemoveAll();
					aszG.Append(tempG);
					tempG.RemoveAll();
					break;
				}
			}
		}
	}
	return TRUE;
}
/****Loai bo nhung phu thuoc ham thua va phu thuoc da tri***/
void CRelate::EssenceD()
{
	int i=0,j;
	while(i<m_aD.GetSize())
	{
		CString tempS;
		tempS=Union(m_aD[i].GetX());
		if(!IsIn(tempS,m_szR)||!m_aD[i].GetFlag())
			m_aD.RemoveAt(i);
		else
		{
			tempS=Common(Union(m_aD[i].GetY()),m_szR);
			if(tempS.IsEmpty())
				m_aD.RemoveAt(i);
			else
			{
				CFunc f=m_aD[i];
				CStringArray aszY;
				aszY.Add(tempS);
				f.SetY(aszY);
				m_aD.SetAt(i,f);
				i++;
			}
		}
	}
	CArray<CFunc,CFunc&> tempD;
	for(i=0;i<m_aD.GetSize();i++)
	{
		for(j=0;j<tempD.GetSize();j++)
			if(tempD[j]==m_aD[i])
				break;
		if(j==tempD.GetSize())
			tempD.Add(m_aD[i]);
	}
	this->SetD(tempD);
}
void CRelate::EssenceR()
{
	m_szR=Essence(m_szR);
}
void CRelate::EssenceRD()
{
	EssenceR();
	EssenceD();
}

/********************Thuat toan phan ra*********************/

//Ham phan ra
//Vao  Relate:Quan he R
//Ra   aDisRelate:mang chua cac quan he 
void DisRelate(CRelate Relate, CArray<CRelate, CRelate&>& aDisRelate)
{
	
	if(Relate.GetR().IsEmpty())
		return;

	int i;
	CArray<CFunc, CFunc&>  aD;
	CStringArray aszTemp;
	CString tempS;
	Relate.GetD(aD);

//Buoc 1
	i=0;
	while(i<aD.GetSize())
	{
		aszTemp.RemoveAll();
		aszTemp.Append(aD[i].GetX());
		aszTemp.Append(aD[i].GetY());
		tempS = Union(aszTemp);

		if(!IsIn(tempS,Relate.GetR()))
			aD.RemoveAt(i);
		else
			i++;
	}

	CRelate tempRelate;
	tempRelate.SetD(aD);
	tempRelate.SetR(Relate.GetR());

//Buoc 2
	
	i=0;
	while(i<aD.GetSize())
	{
		aszTemp.RemoveAll();
		aszTemp.Append(aD[i].GetX());
		aszTemp.Append(aD[i].GetY());
		tempS = Union(aszTemp);

		if(IsEqual(tempS,Relate.GetR()))
			aD.RemoveAt(i);
		else
			i++;
	}

//Buoc 3

	if(aD.GetSize()==0)
		aDisRelate.Add(tempRelate);
	else
	{
		BOOL NotFound=TRUE;	
		for(i=0;(i<aD.GetSize())&&(NotFound);i++)
		{
			CRelate Relate1,Relate2;

			aszTemp.RemoveAll();
			aszTemp.Append(aD[i].GetX());
			aszTemp.Append(aD[i].GetY());
			tempS = Union(aszTemp);
			Relate1 = tempRelate;
			Relate1.SetR(tempS);

			tempS=Union(aD[i].GetY());
			tempS = Sub(Relate.GetR(),tempS);
			Relate2 = tempRelate;
			Relate2.SetR(tempS);

			DisRelate(Relate1,aDisRelate);
			DisRelate(Relate2,aDisRelate);
			NotFound = FALSE;

		}
		if(NotFound)
			AfxMessageBox("Error ! Can't Disintegrate",MB_OK,(UINT)0);
	}
}

/******************Thuat toan phan ra cai tien********************/

//Ham phan ra cai tien : chon ham phan ra la ham vi pham tieu chuan BCK hay
//co ve phai khong xuat hien o ve phai cua cac phu thuoc ham khac
//Vao  Relate:Quan he R
//Ra   aDisRelate:mang chua cac quan he 

void DisRelateEnhanced(CRelate Relate, CArray<CRelate, CRelate&>& aDisRelate)
{
	if(Relate.GetR().IsEmpty())
		return;

	int i,j;
	CArray<CFunc, CFunc&>  aD;
	CStringArray aszTemp;
	CString tempS;
	Relate.GetD(aD);

//Buoc 1
	i=0;
	while(i<aD.GetSize())
	{
		aszTemp.RemoveAll();
		aszTemp.Append(aD[i].GetX());
		aszTemp.Append(aD[i].GetY());
		tempS = Union(aszTemp);

		if(!IsIn(tempS,Relate.GetR()))
			aD.RemoveAt(i);
		else
			i++;
	}

	CRelate tempRelate;
	tempRelate.SetD(aD);
	tempRelate.SetR(Relate.GetR());
	CStringArray aszK;
	tempRelate.FindKey();
	tempRelate.GetK(aszK);

//Buoc 2
	
	i=0;
	while(i<aD.GetSize())
	{
		aszTemp.RemoveAll();
		aszTemp.Append(aD[i].GetX());
		aszTemp.Append(aD[i].GetY());
		tempS = Union(aszTemp);

		if(IsEqual(tempS,Relate.GetR()))
			aD.RemoveAt(i);
		else
			i++;
	}



//Buoc 3
	if(aD.GetSize()==0)
		aDisRelate.Add(tempRelate);
	else
	{
		for(i=0;i<aD.GetSize();i++)
		{
			CString tempS = Union(aD[i].GetX());
			for(j=0;j<aszK.GetSize();j++)
				if(IsIn(aszK[j],tempS))
					break;
			if(j==aszK.GetSize())//khong chua bat cu khoa nao
				break;
		}
		if(i<aD.GetSize())
		{
			CFunc f = aD[i];
			aD.RemoveAt(i);
			aD.InsertAt(0,f);
		}
		else 
		{
			for(i=0;i<aD.GetSize();i++)
			{
				CString tempS = Union(aD[i].GetX());
				for(j=0;j<aD.GetSize();j++)
				{
					if(j!=i)
					{
						CString S=Union(aD[j].GetX());
						if(IsIn(tempS,S))
							break;
					}
				}
				if(j==aD.GetSize())//khong co trong ve phai bat ky phu thuoc ham nao
					break;
			}
			if(i<aD.GetSize())
			{
				CFunc f = aD[i];
				aD.RemoveAt(i);
				aD.InsertAt(0,f);
			}
	
		}
		BOOL NotFound=TRUE;	
		for(i=0;(i<aD.GetSize())&&(NotFound);i++)
		{
			CRelate Relate1,Relate2;

			aszTemp.RemoveAll();
			aszTemp.Append(aD[i].GetX());
			aszTemp.Append(aD[i].GetY());
			tempS = Union(aszTemp);
			Relate1 = tempRelate;
			Relate1.SetR(tempS);

			tempS=Union(aD[i].GetY());
			tempS = Sub(Relate.GetR(),tempS);
			Relate2 = tempRelate;
			Relate2.SetR(tempS);

			DisRelate(Relate1,aDisRelate);
			DisRelate(Relate2,aDisRelate);
			NotFound = FALSE;

		}
		if(NotFound)
			AfxMessageBox("Error ! Can't Disintegrate",MB_OK,(UINT)0);
	}

}

/***********Thuat toan tong hop cai tien(co buoc 7)*************/

//Ham tong hop cai tien
//Vao  Relate:Quan he R
//Ra   aCollectRelate:mang chua cac quan he 
void Collect(CRelate Relate, CArray<CRelate, CRelate&>& aCollectRelate)
{
	if(Relate.IsEmpty())
		return;

	CArray<CFunc, CFunc&>  aPTT;//Mang chua phu toi thieu
	CArray<CFunc, CFunc&>  aJ;//Mang chua phu thuoc ham J
	CArray<CUIntArray,CUIntArray&> aGroup;//Mang nhom
	CUIntArray aGJ;//mang chua xem cac phan tu cua aJ thuoc nhom nao
	int i,j,k;

//Buoc 1,2
	Relate.FindPhuTT(aPTT);
	if(aPTT.GetSize() == 0)
	{
		aCollectRelate.Add(Relate);
		return;
	}

//Buoc 3,4.1,4.2
	k=0;
	for(i=0;i<aPTT.GetSize() - 1;i++)
	{
		CUIntArray aTemp;
		if(!FindUInt((UINT)i,aGroup))//Neu khong co trong nhom
		{
			aTemp.Add((UINT)i);
			for(j=i+1;j<aPTT.GetSize();j++)
			{
				if(!FindUInt((UINT)j,aGroup))//Neu khong co trong nhom
				{
					//Neu ve trai bang nhau
					if(IsEqual( Union(aPTT[j].GetX()),Union(aPTT[i].GetX())))
						aTemp.Add(j);
					else
					{
						CString XF1;
						CRelate tempRelate;
						tempRelate.SetR(Relate.GetR());
						tempRelate.SetD(aPTT);
						tempRelate.BagOfX(Union(aPTT[i].GetX()),XF1);
						if (IsIn(Union(aPTT[j].GetX()),XF1))//Neu Ki->Kj
						{
							CString XF2;
							tempRelate.BagOfX(Union(aPTT[j].GetX()),XF2);
							if (IsIn(Union(aPTT[i].GetX()),XF2))//Neu Kj->Ki
							{
								aTemp.Add(j);

								//Dua vao aJ nhung phu thuoc ham chua co
								CString tempS1 = Union(aPTT[i].GetX());
								CString tempS2 = Union(aPTT[j].GetX());
								for(int h=0;h<aJ.GetSize();h++)
								{
									CString S1 = Union(aJ[h].GetX());
									CString S2 = Union(aJ[h].GetY());
									if(IsEqual(S1,tempS1)&&IsEqual(S2,tempS2))
										break;
								}
								if(h==aJ.GetSize())//Neu trong aJ chua co i,j
								{
									CFunc f;
									f.SetX(aPTT[i].GetX());
									f.SetY(aPTT[j].GetX());
									f.SetFlag(TRUE);
									aJ.Add(f);
									aGJ.Add((UINT)k);

									f.SetX(aPTT[j].GetX());
									f.SetY(aPTT[i].GetX());
									aJ.Add(f);
									aGJ.Add((UINT)k);
								}
							}
						}
					}
				}
			}
		}
		//Chinh thuc tao nhom
		if(aTemp.GetSize()>0)
		{	
			aGroup.SetSize(aGroup.GetSize()+1);
			for(int l=0;l<aTemp.GetSize();l++)
				aGroup[k].SetAtGrow(l, aTemp[l]);
			k++;
		}
	}
	if(!FindUInt((UINT)i,aGroup))
	{
		aGroup.SetSize(aGroup.GetSize()+1);
		aGroup[k].SetAtGrow(0,(UINT)i);	
	}
//Buoc 4.3,4.4
	for(i=0;i<aJ.GetSize();i++)
	{
		CString tempS;
		tempS = Union(aJ[i].GetY());
		CStringArray aszC;
		Combine(tempS,"",0,aszC);//Tao to hop
		Sort(aszC);
		tempS = Union(aJ[i].GetX());
		for(j=0;j<aszC.GetSize();j++)
		{
			for(k=0;k<aPTT.GetSize();k++)
			{
				CString S=Union(aPTT[k].GetX());
				if(IsEqual(S,tempS))
				{
					CString szS=Sub(aPTT[k].GetY(),aszC[j]);
					if(szS.IsEmpty())
					{
						int seg,off;
						//Loai bo phu thuoc co trong aJ
						if(FindUInt(k,aGroup,seg,off))
							aGroup[seg].RemoveAt(off);						
					}
					else 
					{
						CFunc f = aPTT[k];
						CStringArray aszTemp;
						aszTemp.Add(szS);
						f.SetY(aszTemp);
						aPTT.SetAt(k,f);
					}
				}
			}
		}
	}
//Buoc 5.1 5.2

	for(i=0;i<aPTT.GetSize();i++)
	{
		int seg,off;
		if(FindUInt(i,aGroup,seg,off))
		{
			CArray<CFunc,CFunc&> aD;
			for(j=0;j<aPTT.GetSize();j++)
				if(j!=i && FindUInt(j,aGroup))
					aD.Add(aPTT[j]);
			for(j=0;j<aJ.GetSize();j++)
				aD.Add(aJ[j]);

			CRelate tempRelate;
			tempRelate.SetR(Relate.GetR());
			tempRelate.SetD(aD);
			CString tempS = Union(aPTT[i].GetX());
			CString S;
			tempRelate.BagOfX(tempS,S);
			tempS = Union(aPTT[i].GetY());
			if(IsIn(tempS,S))
				aGroup[seg].RemoveAt(off);//huy phu thuoc ham bac cau
		}
	}

//Buoc 5.3 : Dua aJ vao nhom
	for(i=0;i<aGJ.GetSize();i++)
	{
		int seg=aGJ[i];
		aGroup[seg].Add(10000+i);
	}
	i=0;
	//Xoa nhung Group[i] rong
	while(i<aGroup.GetSize())
	{
		if(aGroup[i].GetSize()==0)
			aGroup.RemoveAt(i);
		else
			i++;
	}


//Buoc 6
	for(i=0;i<aGroup.GetSize();i++)
	{
		CRelate tempRelate;
		CString tempS;
		CArray<CFunc, CFunc&>  aD;
		for(j=0;j<aGroup[i].GetSize();j++)
		{
			CFunc f;
			int n=aGroup[i][j];
			if(n<10000)//Neu tu tap phu toi thieu
			{
				f=aPTT[n];
				aD.Add(f);
				tempS = Union(tempS,Union(aPTT[n].GetX(),
							aPTT[n].GetY()));
			}
			else//Neu tu tap aJ
			{
				f=aJ[n-10000];
				aD.Add(f);
				tempS = Union(tempS,Union(aJ[n-10000].GetX(),
							aJ[n-10000].GetY()));
			}
		
		}
		tempRelate.SetR(tempS);
		tempRelate.SetD(aD);
		aCollectRelate.Add(tempRelate);
	}

//Buoc 7
	if(Relate.FindKey())
	{
		CStringArray aszK;
		Relate.GetK(aszK);
		CString szK = aszK[0];
		for(i=0;i<aCollectRelate.GetSize();i++)
		{
			CRelate tempRelate = aCollectRelate[i];
			if(tempRelate.FindKey())
			{
				CStringArray aszTempK;
				tempRelate.GetK(aszTempK);
				for(j=0;j<aszTempK.GetSize();j++)
					if(IsEqual(szK,aszTempK[j]))
						break;
				if(j<aszTempK.GetSize())//neu co khoa tap con nhu vay
					break;
			}
			
		}
		if(i==aCollectRelate.GetSize())
		{
			CRelate tempRelate;
			tempRelate.SetR(aszK[0]);
			aCollectRelate.Add(tempRelate);
		}
	}
	
}

/**********Thuat toan bieu dien mot phan ra duoi dang do thi********/
//Vao : phan ra aInput;
//Ra  : tap cac nut aOutput
//      Ma tran ke aGraph
BOOL PerformToGraph(CArray<CRelate,CRelate&>& aInput,
					CArray<CRelate,CRelate&>& aOutput,
					CArray<CUIntArray,CUIntArray&>& aGraph)
{
	if(aInput.GetSize()==0)
		return FALSE;
	int i,j,k,n;
	aOutput.RemoveAll();
	for(i=0;i<aGraph.GetSize();i++)
		aGraph[i].RemoveAll();
	aGraph.RemoveAll();

	CRelate Relate(aInput);//day la quan he tong quat
	
	CArray<CRelate,CRelate&> aTemp;
	CUIntArray aHinge;//Nut ban le
	CArray<CFunc,CFunc&> aD;
	Relate.GetD(aD);
	
	
//Buoc 1.1;
	for(i=0;i<aInput.GetSize();i++)
		aTemp.Add(aInput[i]);
	for(i=0;i<aTemp.GetSize();i++)
	{
		aTemp[i].SetD(aD);
		aTemp[i].EssenceRD();
	}


	for(i=0;i<aTemp.GetSize();i++)
	{
		CStringArray aszKi,aszX;
		aTemp[i].FindKey();
		aTemp[i].GetK(aszKi);
		if(!Relate.BagOfX(aszKi,aszX))
			continue;
		
		for(j=0;j<aOutput.GetSize();j++)
		{
			CStringArray aszKj,aszY;
			aOutput[j].FindKey();
			aOutput[j].GetK(aszKj);
			int idx1,idx2;
			if(IsInF(aszKj,aszX,idx1,idx2))//Neu Ki->Kj
			{
				int idx3,idx4;
				if(!Relate.BagOfX(aszKj,aszY))
					continue;
				if(IsInF(aszKi,aszY,idx3,idx4))//Neu Ki<-Kj
					if(idx2==idx3&&idx1==idx4) //Neu Ki<->Kj
						break;
			}
		}
		if(j==aOutput.GetSize())
			aOutput.Add(aTemp[i]);
		else
		{
			CRelate tempRelate;
			tempRelate=(aTemp[i]+aOutput[j]);
			tempRelate.EssenceRD();
			aOutput.SetAt(j,tempRelate);
		}
	}


//Buoc 1.2; Neu Qi chua mot khoa cua Qj thi Qi chua tat ca cac khoa
			//con lai cua Qj
	for(i=0;i<aOutput.GetSize();i++)
		for(j=0;j<aOutput.GetSize();j++)
			if(j!=i)
			{
				CStringArray aszKj;
				aOutput[j].FindKey();
				aOutput[j].GetK(aszKj);
				int idx;
				//Neu Qi co chua mot khoa cua Qj
				if(IsInF(aszKj,aOutput[i].GetR(),idx))
				{
					CString szR,tempS;
					szR=Union(aOutput[i].GetR(),aszKj);

					aOutput[i].SetR(szR);//Qi chua tat ca cac khoa con lai
					aOutput[i].SetD(aD);
					aOutput[i].EssenceRD();
				}
			}

	aTemp.RemoveAll();


//Buoc 3 : Tao nut ban le
	n=aOutput.GetUpperBound();
	for(i=0;i<aOutput.GetSize()-1;i++)
		for(j=i+1;j<aOutput.GetSize();j++)
		{
			CString szR;
			szR=Common(aOutput[i].GetR(),aOutput[j].GetR());
			while(!szR.IsEmpty())
			{
				CRelate tempRelate;
				CStringArray aszK;

				tempRelate.SetD(aD);
				tempRelate.SetR(szR);
				tempRelate.EssenceRD();
				tempRelate.FindKey();
				tempRelate.GetK(aszK);
				
				for(k=0;k<aOutput.GetSize();k++)
				{
					CStringArray aszX;
					aOutput[k].FindKey();
					aOutput[k].GetK(aszX);
					if(IsEqualSpecial(aszX,aszK))
						break;
				}
				if(k==aOutput.GetSize())//Neu khong ton tai
				{
					CRelate tempRelate;
					tempRelate.SetR(Essence(Union(aszK)));
					tempRelate.SetD(aD);
					tempRelate.EssenceRD();

					aTemp.Add(tempRelate);
					n++;
					aHinge.Add(n);
				}
				szR=Sub(szR,aszK);

			}//Cuoi while
		}
	for(i=0;i<aTemp.GetSize();i++)
		aOutput.Add(aTemp[i]);//Them nut ban le vao
	n=aOutput.GetSize();
	for(i=0;i<n;i++)
		aOutput[i].FindKey();//Tim khoa cho tat ca cac quan he

	aGraph.SetSize(n);
	//Khoi dong ma tran ke
	for(i=0;i<n;i++)
	{
		aGraph[i].SetSize(n);
		for(j=0;j<n;j++)
			aGraph[i][j]=0;
	}
	aTemp.RemoveAll();


//Buoc 4 : Tao cung
	for(i=0;i<n;i++)
	{
		CUIntArray aPTH;	
		CUIntArray aPTH_THUA;	
		CUIntArray aLONG_KHOA;	
		CUIntArray aLONG_KHOA_THUA;	

		//Tao PTH,LONG_KHOA
		for(j=0;j<n;j++)
			if(j!=i)
			{
				CString szR;
				CStringArray aszKi,aszKj;
				int idx1,idx2;

				szR=aOutput[i].GetR();
				aOutput[i].GetK(aszKi);

				aOutput[j].GetK(aszKj);
				if(IsInF(aszKj,szR,idx1))
					aPTH.Add(j);//Tao long khoa
				if(IsInF(aszKj,aszKi,idx1,idx2))
					aLONG_KHOA.Add(j);

			}

		//Tao PTH_THUA
		for(j=0;j<aPTH.GetSize();j++)
		{
			for(k=0;k<aPTH.GetSize();k++)
				if(k!=j)
				{
					CStringArray aszKj,aszKk;
					int idx1,idx2;

					aOutput[aPTH[j]].GetK(aszKj);
					aOutput[aPTH[k]].GetK(aszKk);
					if(IsInF(aszKj,aszKk,idx1,idx2))
						break;
				}
			if(k<aPTH.GetSize())//Neu co
				aPTH_THUA.Add(aPTH[j]);
		}
		//Tao LONG_KHOA_THUA
		for(j=0;j<aLONG_KHOA.GetSize();j++)
		{
			for(k=0;k<aLONG_KHOA.GetSize();k++)
				if(k!=j)
				{
					CStringArray aszKj,aszKk;
					int idx1,idx2;

					aOutput[aLONG_KHOA[j]].GetK(aszKj);
					aOutput[aLONG_KHOA[k]].GetK(aszKk);
					if(IsInF(aszKj,aszKk,idx1,idx2))
						break;
				}
			if(k<aLONG_KHOA.GetSize())//Neu co
				aLONG_KHOA_THUA.Add(aPTH[j]);
		}
		CUIntArray aTemp,aTemp1,aTemp2;
		Sub(aPTH,aPTH_THUA,aTemp1);
		Sub(aLONG_KHOA,aLONG_KHOA_THUA,aTemp2);
		Union(aTemp1,aTemp2,aTemp);

		//Tao ma tran ke
		for(j=0;j<aTemp.GetSize();j++)
			aGraph[i].SetAt(aTemp[j],1);
	}

//Buoc 5: Huy nhung nut ban le
	i=0;
	while(i<aHinge.GetSize())
	{
		CStringArray aszK;
		int idx=aHinge[i];
		aOutput[idx].GetK(aszK);
		//Neu co 1 khoa duy nhat va khong co thuoc tinh ngoai khoa
		if(aszK.GetSize()==1&&IsEqual(aOutput[idx].GetR(),aszK))
		{
			for(j=0;j<aGraph[idx].GetSize();j++)
				if(aGraph[idx][j]==1)
					break;
			if(j==aGraph[idx].GetSize())//Neu khong co cung ra
			{
				int count=0,offset;
				for(j=0;j<aGraph.GetSize();j++)
				{
					if(j!=idx&&aGraph[j][idx]==1)
					{
						count++;
						offset=j;
						if(count>1)
							break;
					}
				}
				if(count==1)//Neu chi co duy nhat 1 cung vao
				{
					CRelate tempRelate=aOutput[idx];
					aHinge.RemoveAt(i);//Huy nu ban le
					aOutput.RemoveAt(idx);//Huy nut ban le
					aGraph.RemoveAt(idx);//Xoa dong tuon ung voi nut ban le
					for(j=0;j<aGraph.GetSize();j++)
						aGraph[j].RemoveAt(idx);//Xoa cot tuong ung voi nu ban le
					
					aOutput[offset].GetK(aszK);
					aOutput[offset]+=tempRelate;
					aOutput[offset].EssenceRD();
					//aOutput[offset].FindKey();
					aOutput[offset].SetK(aszK);
					continue;
				}

			}
		}
		i++;
	}

	n=aOutput.GetSize();
//Buoc 6: Min hoa cac quan he nut;

	for(i=0;i<n;i++)
	{
		CStringArray aszKi;
		CString      szKi,szR;
		aOutput[i].GetK(aszKi);szKi=Union(aszKi);
		szR=aOutput[i].GetR();
		for(j=0;j<n;j++)
			if(aGraph[i][j]==1)//Neu co cung noi nut i,j
			{
				CStringArray aszKj;
				CString      szKj,tempS;

				aOutput[j].GetK(aszKj);szKj=Union(aszKj);

				for(k=0;k<szR.GetLength();k++)
					if(szKi.Find(szR[k])==-1&&szKj.Find(szR[k])!=-1)
						tempS+=szR[k];	//Neu szR[k] khong la thuoc tinh khoa 
										//cua Qi nhung lai la thuoc tinh khoa cua Qj

				szR=Sub(szR,tempS);
				aOutput[i].SetR(szR);
				aOutput[i].EssenceD();
				//aOutput[i].FindKey();
				aOutput[i].SetK(aszKi);
			}
	}
//Buoc 7: Tao cung vo huong
	i=0;
	while(i<aOutput.GetSize())
	{
		CStringArray aszK;
		aOutput[i].GetK(aszK);
		if(IsEqual(aOutput[i].GetR(),aszK))//Qi khong co thuoc tinh khong khoa
		{
			for(j=0;j<aGraph.GetSize();j++)
				if(aGraph[j][i]==1)
					break;
			if(j==aGraph.GetSize())//Neu khong co cung vao
			{
				int idx=0,Node[2];

				for(j=0;j<aGraph[i].GetSize();j++)
				{
					if(aGraph[i][j]==1)
					{
						if(idx<2)
							Node[idx]=j;
						idx++;
						if(idx>2)
							break;
					}
				}
				if(idx==2)//Neu chi co 2 cung ra
				{
					CStringArray aszK1,aszK2;
					aOutput[Node[0]].GetK(aszK1);
					aOutput[Node[1]].GetK(aszK2);

					for(k=0;k<aszK.GetSize();k++)
					{
						//Cac bien i,j cuc bo
						for(int i=0;i<aszK1.GetSize();i++)
						{
							for(int j=0;j<aszK2.GetSize();j++)
							{
								CString tempS;
								tempS=Union(aszK1[i],aszK2[j]);
								if(IsEqual(aszK[k],tempS))//Neu KQk=KQi + KQj
									break;
							}
							if(j<aszK2.GetSize())
								break;
						}
						if(i<aszK1.GetSize())
							break;
					}
					if(k<aszK.GetSize())//Neu KQk=KQi + KQj
					{
						//Tao cung vo huong
						aGraph[Node[0]][Node[1]]=1;												
						aGraph[Node[1]][Node[0]]=1;
						//Huy nut i
						aGraph.RemoveAt(i);
						for(j=0;j<aGraph.GetSize();j++)
							aGraph[j].RemoveAt(i);

						aOutput.RemoveAt(i);
						continue;
					}
				}
			}
		}
		i++;
	}
	
	return TRUE;
}
BOOL CheckTrue(CArray<BOOL,BOOL>& a)
{
	int n=a.GetSize();
	if(n==0)
		return FALSE;
	for(int i=0;i<n;i++)
		if(!a[i])
			return FALSE;
	return TRUE;
}

//Vao : tap cac quan he aQ
//Ra  : TRUE neu bao toan thong tin
//      FALSE neu khong bao toan thong tin
BOOL Tableau(CArray<CRelate,CRelate&>& aQ)
{
	CArray<CArray<BOOL,BOOL>,CArray<BOOL,BOOL>& > aTableau;
	int i,j,k,m,n,step;
	BOOL Flag;
	CString szR	;
	CArray<CFunc,CFunc&> aD;
	CRelate Q;

	m=aQ.GetSize();
	Q=aQ;//Tao quan he cha
	Q.EssenceRD();
	szR=Q.GetR();
	n=szR.GetLength();

//Khoi tao bang Tableau moi phan tu la TRUE neu co thuoc tinh nguoc lai la FALSE
	aTableau.SetSize(m);
	for(i=0;i<m;i++)
	{
		aTableau[i].SetSize(n);
		CString tmpS=aQ[i].GetR();

		for(j=0;j<n;j++)
		{
			if(tmpS.Find(szR[j])!=-1)
				aTableau[i][j]=TRUE;
			else
				aTableau[i][j]=FALSE;
		}
	}
//Kiem tra
	Q.GetD(aD);
	i=0;
	int count=0;
	while(i<aD.GetSize())
	{
		CString tmpS=Union(aD[i].GetX());
		if(!IsIn(tmpS,szR) || !aD[i].GetFlag())
			aD.RemoveAt(i);//Loai bo nhung phu thuoc da tri hoac khong nam trong Q	
		else
			i++;
	}
	if(aD.GetSize()==0)
		return FALSE;

	step=0;//bien chay cho phu thuoc ham
	Flag=FALSE;
	while(1)
	{
		CUIntArray a;//bang chi muc
		CString tmpS=Union(aD[step].GetX());
		for(k=0;k<tmpS.GetLength();k++)
			a.Add(szR.Find(tmpS[k]));				

		for(i=0;i<m;i++)
		{
			if(CheckTrue(aTableau[i]))
				return TRUE;
			for(j=0;j<m;j++)
			{
				if(j==i)
					continue;
				if(CheckTrue(aTableau[j]))
					return TRUE;
				for(k=0;k<a.GetSize();k++)
				{
					if(!aTableau[i].GetAt(a[k]) || !aTableau[j].GetAt(a[k]))
						break;
				}
				if(k<a.GetSize())
					continue;
				a.RemoveAll();

				tmpS=Union(aD[step].GetY());
				for(k=0;k<tmpS.GetLength();k++)
					a.Add(szR.Find(tmpS[k]));				
	
				for(k=0;k<a.GetSize();k++)
				{
					if(aTableau[i].GetAt(a[k]))
					{
						if(!aTableau[j].GetAt(a[k]))
						{
							aTableau[j].SetAt(a[k],TRUE);
							if(CheckTrue(aTableau[j]))
								return TRUE;
							
							Flag=TRUE;//co thay doi
						}
					}
					else 
					{
						if(aTableau[j].GetAt(a[k]))
						{
							aTableau[i].SetAt(a[k],TRUE);
							if(CheckTrue(aTableau[i]))
								return TRUE;
							Flag=TRUE;//co thay doi
						}
					}
				}
			}
		}
		step++;
		count++;
		if(step==aD.GetSize())//Het 1 chu ki reset lai
		{
			for(i=0;i<aTableau.GetSize();i++)
				if(CheckTrue(aTableau[i]))
					return TRUE;
			if(!Flag)
				return FALSE;
			else
			{
				step=0;
				Flag=FALSE;
			}
		}
	}
	return FALSE;
}





