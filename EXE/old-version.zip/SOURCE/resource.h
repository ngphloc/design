//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Design.rc
//
#define IDC_VIEW_FULL_BUTTON            10
#define IDC_PERFORM_BUTTON              11
#define IDC_TABLEAU_BUTTON              12
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DESIGN_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_BAG_OF_X_DIALOG             130
#define IDD_DEPEND_OF_X_DIALOG          131
#define IDD_VIEW_D_FULL_DIALOG          132
#define IDD_DIS_DIALOG                  133
#define IDR_DESIGN_MENU                 134
#define IDD_HELP_DIALOG                 135
#define IDD_PTT_DIALOG                  136
#define IDD_MINI_DIALOG                 137
#define IDD_VIEW_COLLECT_FULL_DIALOG    138
#define IDR_DESIGN_ACCELERATOR          139
#define IDI_DESIGN_ICON                 140
#define IDD_GRAPH_DIALOG                141
#define IDD_PERFORM_DIALOG              142
#define IDD_CHOOSE_DIALOG               143
#define IDD_NODE_ARG_DIALOG             145
#define IDD_GRAPH_HELP_DIALOG           149
#define IDC_R_EDIT                      1000
#define IDC_D_EDIT                      1001
#define IDC_FIND_KEY_BUTTON             1002
#define IDC_BAG_OF_X_BUTTON             1003
#define IDC_DEPEND_OF_X_BUTTON          1004
#define IDC_DIS_RELATE_BUTTON           1005
#define IDC_PTT_BUTTON                  1006
#define IDC_COLLECT_BUTTON              1007
#define IDC_CO_SO_TT_BUTTON             1008
#define IDC_DIS_RELATE_ENHANCED_BUTTON  1009
#define IDC_GRAPH_BUTTON                1010
#define IDC_ACCEPT_BUTTON               1011
#define IDC_VIEW_D_FULL_BUTTON          1012
#define IDC_CLEAR_BUTTON                1013
#define IDC_X_EDIT                      1014
#define IDC_VIEW_COLLECT_FULL_BUTTON    1015
#define IDC_KEY_EDIT                    1025
#define IDC_BAG_OF_X_EDIT               1026
#define IDC_DEPEND_OF_X_EDIT            1027
#define IDC_DIS_RELATE_EDIT             1028
#define IDC_BX_EDIT                     1029
#define IDC_DX_EDIT                     1030
#define IDC_COLLECT_EDIT                1031
#define IDC_VIEW_D_FULL_LIST            1033
#define IDC_VALUE_EDIT                  1034
#define IDC_KEY_STATIC                  1035
#define IDC_HELP_EDIT                   1036
#define IDC_PTT_LIST                    1037
#define IDC_SOURCE_EDIT                 1038
#define IDC_DEST_EDIT                   1039
#define IDC_AGREE_BUTTON                1040
#define IDC_DEL_BUTTON                  1041
#define IDC_VIEW_D_FULL_EDIT            1042
#define IDC_VIEW_COLLECT_FULL_EDIT      1043
#define IDC_ENTER_EDIT                  1044
#define IDC_VALUE_COMBO                 1045
#define IDC_GRAPH_MSFLEXGRID            1049
#define IDC_NODE_STATIC                 1052
#define IDC_NODE_I_STATIC               1052
#define IDC_NODE_EDIT                   1053
#define IDC_NODE_J_STATIC               1053
#define IDC_ARG_STATIC                  1054
#define IDC_ARG_I_STATIC                1054
#define IDC_ARG_EDIT                    1055
#define IDC_ARG_J_STATIC                1055
#define IDC_FIND_KEY_NODE_BUTTON        1056
#define IDC_KEY_NODE_EDIT               1057
#define IDC_KEY_NODE_STATIC             1058
#define IDC_FIND_KEY_ARG_BUTTON         1059
#define IDC_NODE_I_EDIT                 1059
#define IDC_KEY_ARG_EDIT                1060
#define IDC_NODE_J_EDIT                 1060
#define IDC_KEY_ARG_STATIC              1061
#define IDC_ARG_I_EDIT                  1061
#define IDC_ARG_J_EDIT                  1062
#define IDC_Qo_EDIT                     1062
#define IDC_FIND_KEY_Qo_BUTTON          1063
#define IDC_KEY_Qo_EDIT                 1064
#define IDC_KEY_Qo_STATIC               1065
#define ID_FILE_SAVEAS                  32775
#define ID_FILE_EXIT                    32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
