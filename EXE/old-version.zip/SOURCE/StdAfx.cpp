// stdafx.cpp : source file that includes just the standard includes
//	Design.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
	  /************************************************
	   * Sinh vien : Nguyen Phuoc Loc    MSSV: 9700454*
	   ************************************************/

#include "stdafx.h"



